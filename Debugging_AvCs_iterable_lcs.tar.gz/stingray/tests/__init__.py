# Licensed under MIT license - see LICENSE.rst
"""
This packages contains affiliated package tests.
"""
