# Exception Handling for Stingray

__all__ = ["StingrayError"]

class StingrayError(Exception):
    pass

